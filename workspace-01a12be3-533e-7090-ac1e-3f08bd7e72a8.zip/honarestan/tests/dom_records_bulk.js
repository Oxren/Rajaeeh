
const fs=require('fs'); const {JSDOM, VirtualConsole}=require(process.env.JSDOM_PATH || 'jsdom');
const html=fs.readFileSync('/tmp/hs_r_bulk.html','utf8');
const errs=[]; const vc=new VirtualConsole();
vc.on('jsdomError',e=>errs.push('jsdomError: '+e.message)); vc.on('error',e=>errs.push('error: '+e));
const dom=new JSDOM(html,{runScripts:'dangerously',pretendToBeVisual:true,url:'http://127.0.0.1:8080/records.php?tab=bulk',virtualConsole:vc});
setTimeout(()=>{
  const w=dom.window,d=w.document,out=[],ok=(n,c)=>out.push((c?'✅':'❌')+' '+n);
  const pane=d.getElementById('pane-bulk');
  ok('پنل ثبت گروهی در DOM هست', !!pane);
  if(!pane){ console.log(out.join('\n')); process.exit(0); }
  const cbs=[...pane.querySelectorAll('.bp-cb')];
  ok('چک‌باکس همهٔ دانش‌آموزان ('+cbs.length+')', cbs.length>0);
  ok('شمارنده در ابتدا صفر', /۰/.test(d.getElementById('bulkCount').textContent));
  const vis=()=>cbs.filter(c=>!c.closest('.bp-item').classList.contains('hidden'));
  const g=d.getElementById('bulkFGrade'), f=d.getElementById('bulkFField');
  g.value='دهم'; g.dispatchEvent(new w.Event('change',{bubbles:true}));
  ok('فیلتر پایه دهم → '+vis().length+' دانش‌آموز', vis().length>0 && vis().length<cbs.length);
  ok('رشته‌های فیلتر دهم شامل کامپیوتر است', [...f.options].some(o=>o.value==='کامپیوتر'));
  d.getElementById('bulkAllVisible').dispatchEvent(new w.Event('click',{bubbles:true}));
  ok('انتخاب همهٔ نتایج فیلتر → همه تیک خوردند', vis().every(c=>c.checked));
  ok('شمارنده به‌روز شد', !/۰ دانش‌آموز/.test(d.getElementById('bulkCount').textContent));
  ok('دکمهٔ ثبت تعداد را نشان می‌دهد', /[۱-۹]/.test(d.getElementById('bulkSubmitN').textContent));
  d.getElementById('bulkInvert').dispatchEvent(new w.Event('click',{bubbles:true}));
  ok('معکوس → هیچ انتخاب از موارد فیلترشده', vis().every(c=>!c.checked));
  g.value=''; g.dispatchEvent(new w.Event('change',{bubbles:true}));   /* پاک کردن فیلتر پایه برای جستجوی سراسری */
  const q=d.getElementById('bulkFQ'); q.value='یاسین'; q.dispatchEvent(new w.Event('input',{bubbles:true}));
  ok('جستجوی «یاسین» → ۱ مورد', vis().length===1);
  q.value=''; q.dispatchEvent(new w.Event('input',{bubbles:true}));
  const kind=d.getElementById('bulkKind');
  kind.value='discipline'; kind.dispatchEvent(new w.Event('change',{bubbles:true}));
  ok('با نوع انضباطی، کادر نوع و کسر نمایش داده شد', !d.getElementById('bulkDiscBox').classList.contains('hidden'));
  ok('کادر ساعت تأخیر پنهان شد', d.getElementById('bulkTimeBox').classList.contains('hidden'));
  kind.value='dress'; kind.dispatchEvent(new w.Event('change',{bubbles:true}));
  ok('با نوع پوششی، فیلد پوششی فعال شد', !d.getElementById('bulkDressBox').classList.contains('hidden'));
  kind.value='delay'; kind.dispatchEvent(new w.Event('change',{bubbles:true}));
  ok('بازگشت به تأخیر: فیلد زنگ فعال', !d.getElementById('bulkTimeBox').classList.contains('hidden'));
  const jd=d.getElementById('bulkJdate');
  jd.value='1405/07/23'; jd.dispatchEvent(new w.Event('change',{bubbles:true}));
  ok('تاریخ تعطیل → یادداشت قرمز نمایش داده شد', d.querySelectorAll('.offday-note.show').length>0);
  jd.value='1405/07/21'; jd.dispatchEvent(new w.Event('change',{bubbles:true}));
  ok('تاریخ کاری → یادداشت پنهان شد', d.querySelectorAll('.offday-note.show').length===0);
  console.log(out.join('\n'));
  const real=errs.filter(e=>!/scrollTo|Not implemented/i.test(e));
  console.log(real.length?'❌ خطاهای JS:\n'+real.join('\n'):'✅ بدون خطای جاوااسکریپت');
  process.exit(0);
},350);
