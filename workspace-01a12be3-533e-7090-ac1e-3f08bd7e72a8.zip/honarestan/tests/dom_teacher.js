const fs = require('fs');
const { JSDOM, VirtualConsole } = require(process.env.JSDOM_PATH || 'jsdom');
const html = fs.readFileSync(process.argv[2], 'utf8');
const errs = [];
const vc = new VirtualConsole();
vc.on('jsdomError', e => errs.push('jsdomError: ' + e.message));
vc.on('error', e => errs.push('error: ' + e));
const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true,
  url: 'http://127.0.0.1:8080/teacher.php', virtualConsole: vc });
const w = dom.window;
setTimeout(() => {
  const d = w.document, out = [];
  const ok = (n, c) => out.push((c ? '✅' : '❌') + ' ' + n);
  const $ = s => d.querySelector(s), $$ = s => Array.from(d.querySelectorAll(s));

  // ۰) آیکون‌های برداری (بدون ایموجی)
  const icons = $$('svg.hs-i');
  ok('آیکون‌های خطی SVG در صفحه (' + icons.length + ')', icons.length > 10);
  const emoji = /[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/u;
  ok('بدون ایموجی در متن صفحه', !emoji.test(d.body.textContent));

  // ۱) ساختار صفحهٔ پنل
  ok('پنل معلم بارگذاری شد (سربرگ)', /پنل معلم — کلاس‌های من/.test(d.body.textContent));
  const grades = $$('.tp-grade');
  ok('سه دکمهٔ پایه وجود دارد (' + grades.length + ')', grades.length === 3);
  ok('برچسب پایه‌ها: دهم/یازدهم/دوازدهم',
     /دهم/.test(grades[0].textContent) && /یازدهم/.test(grades[1].textContent) && /دوازدهم/.test(grades[2].textContent));

  // ۲) رشته‌های پایهٔ انتخاب‌شده (دهم → ۶ رشته)
  const fields = $$('.tp-field');
  ok('چیپ‌های رشته نمایش داده شد (' + fields.length + ')', fields.length === 6);
  const allFields = fields.map(f => f.textContent.trim());
  ok('رشتهٔ کامپیوتر در پایهٔ دهم موجود است', allFields.some(t => t.indexOf('کامپیوتر') === 0));
  ok('رشتهٔ انتخاب‌شده برجسته است', fields.some(f => f.classList.contains('on')));

  // ۳) فهرست کلاس و دکمه‌های ثبت
  const rows = $$('#tpTable tbody tr');
  ok('ردیف دانش‌آموزان کلاس (' + rows.length + ')', rows.length >= 1);
  const acts = $$('.tp-act');
  ok('دکمه‌های ثبت در هر ردیف (' + acts.length + ')', acts.length >= 1);
  const kinds = Array.from(new Set(acts.map(a => a.dataset.act)));
  ok('دکمه‌های تأخیر و غیبت برای معلم موجودند (بر اساس پرمیشن)',
     kinds.indexOf('delay') > -1 && kinds.indexOf('absence') > -1);
  ok('دکمه‌های انضباطی/پوششی برای معلم پنهان‌اند (پرمیشن ندارد)',
     kinds.indexOf('discipline') === -1 && kinds.indexOf('dress') === -1);

  // ۴) باز شدن پنجرهٔ ثبت با کلیک روی دکمه
  const delayBtn = $('.tp-act[data-act="delay"]');
  delayBtn.dispatchEvent(new w.Event('click', { bubbles: true }));
  const mDelay = $('#md-delay');
  ok('پنجرهٔ تأخیر باز شد', mDelay && mDelay.classList.contains('show'));
  ok('نام دانش‌آموز در پنجره درست است',
     mDelay.querySelector('[data-mname]').textContent === delayBtn.dataset.name);
  ok('شناسهٔ دانش‌آموز در فرم قرار گرفت',
     mDelay.querySelector('[data-sid]').value === delayBtn.dataset.sid);

  // ۵) چیپ‌های زنگ → پر شدن ساعت
  const chips = $$('#md-delay .bell-chip');
  ok('چیپ‌های زنگ در پنجرهٔ تأخیر (' + chips.length + ')', chips.length >= 4);
  chips[2].dispatchEvent(new w.Event('click', { bubbles: true }));
  const tInp = $('#md-delay [data-time]');
  ok('کلیک روی زنگ سوم ساعت را 09:45 کرد', tInp.value === '09:45');
  ok('زنگ انتخاب‌شده برجسته شد', chips[2].classList.contains('on'));
  ok('نام زنگ زیر فیلد نمایش داده شد', /زنگ سوم/.test($('#md-delay .bell-info').textContent));

  // ۶) پنجرهٔ غیبت: بدون فیلد توضیحات (سامانه خودش می‌نویسد) + تاریخ و روز هفتهٔ خودکار
  const absBtn = $('.tp-act[data-act="absence"]');
  absBtn.dispatchEvent(new w.Event('click', { bubbles: true }));
  const mAbs = $('#md-absence');
  ok('پنجرهٔ غیبت باز شد', mAbs && mAbs.classList.contains('show'));
  const dow = mAbs.querySelector('[data-dowview]');
  ok('روز هفته خودکار نمایش داده شد', dow && dow.value.length > 3);
  ok('فیلد «توضیحات/دلیل» حذف شده است (معلم چیزی تایپ نمی‌کند)',
     !mAbs.querySelector('input[name="description"], textarea[name="description"]'));
  ok('کارت «توضیحات خودکار» نمایش داده می‌شود', !!mAbs.querySelector('.auto-note')
     && /توضیحات غیبت نیازی به نوشتن ندارد/.test(mAbs.textContent));
  ok('فیلد کلاس/درس وجود دارد', !!mAbs.querySelector('input[name="lesson"]'));
  ok('چیپ‌های زنگ در غیبت موجودند', mAbs.querySelectorAll('.bell-chip').length >= 4);
  ok('فرم غیبت بدون فیلد اجباری متنی ارسال می‌شود', mAbs.querySelector('form').checkValidity());

  // ۷) بستن پنجره
  mAbs.querySelector('[data-close]').dispatchEvent(new w.Event('click', { bubbles: true }));
  ok('دکمهٔ بستن پنجره را می‌بندد', !mAbs.classList.contains('show'));

  // ۸) دکمهٔ حذف رکورد (غیبت اشتباهی) + پنجرهٔ تأیید
  const delForms = $$('form[data-rdel]');
  ok('دکمهٔ حذف برای رکوردهای سوابق روز ساخته شده (' + delForms.length + ')', delForms.length >= 0);
  if (delForms.length) {
    const f = delForms[0];
    ok('فرم حذف نام رکورد را برای تأیید دارد', !!f.dataset.name && !!f.dataset.title);
    const btn = f.querySelector('button[type="submit"]');
    btn.dispatchEvent(new w.Event('click', { bubbles: true }));
    f.dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
    const cf = d.getElementById('hs-confirm');
    ok('کلیک روی حذف، پنجرهٔ تأیید را باز می‌کند', !!cf && cf.classList.contains('show'));
    ok('پیام تأیید نام دانش‌آموز را نشان می‌دهد', !!cf && cf.textContent.indexOf(f.dataset.name) > -1);
    ok('فرم تا زمان تأیید ارسال نشده است', f.dataset.done !== '1');
    const no = d.getElementById('hs-cf-no');
    if (no) no.dispatchEvent(new w.Event('click', { bubbles: true }));
    ok('با انصراف، پنجره بسته می‌شود', !cf.classList.contains('show'));
  }

  // ۹) جستجو در فهرست کلاس
  const q = $('#tpSearch');
  if (q && rows.length) {
    const first = rows[0].dataset.search.split(' ')[0];
    q.value = first;
    q.dispatchEvent(new w.Event('input', { bubbles: true }));
    const visible = rows.filter(r => r.style.display !== 'none');
    ok('جستجوی کلاس نتیجه می‌دهد (' + visible.length + ' ردیف)', visible.length >= 1 && visible.length <= rows.length);
    q.value = '';
    q.dispatchEvent(new w.Event('input', { bubbles: true }));
  }

  console.log(out.join('\n'));
  const real = errs.filter(e => !/Not implemented|scrollTo/i.test(e));
  console.log(real.length ? '❌ خطاهای JS:\n' + real.join('\n') : '✅ بدون خطای جاوااسکریپت');
  process.exit(0);
}, 320);
