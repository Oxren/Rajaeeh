
const fs = require('fs');
const { JSDOM, VirtualConsole } = require(process.env.JSDOM_PATH || 'jsdom');
const errs = [];
const html = fs.readFileSync(process.argv[2], 'utf8');
const vc = new VirtualConsole();
vc.on('jsdomError', e => errs.push('jsdomError: ' + e.message));
vc.on('error', e => errs.push('error: ' + e));
const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true,
  url: 'http://127.0.0.1:8080/' + process.argv[3], virtualConsole: vc });
const w = dom.window;
setTimeout(() => {
  const d = w.document, out = [];
  const ok = (n, c) => out.push((c ? '✅' : '❌') + ' ' + n);
  const off = d.querySelectorAll('[data-offcheck]');
  ok('فیلدهای data-offcheck پیدا شد (' + off.length + ')', off.length > 0);
  if (off.length) {
    const inp = off[0];
    const noteOf = i2 => i2.parentNode.querySelector('.offday-note')
      || (i2.id ? d.querySelector('.offday-note[data-offnote="' + i2.id + '"]') : null)
      || (i2.parentNode.parentNode ? i2.parentNode.parentNode.querySelector('.offday-note') : null);
    ok('یادداشت .offday-note در DOM وجود دارد', !!noteOf(inp));
    inp.value = '1405/07/23';
    inp.dispatchEvent(new w.Event('change', { bubbles: true }));
    ok('پس از انتخاب پنج‌شنبه، یادداشت تعطیلی نمایش داده شد', d.querySelectorAll('.offday-note.show').length > 0);
    ok('کلاس offday به فیلد اضافه شد', inp.classList.contains('offday'));
    ok('متن یادداشت شامل «تعطیل» است', /تعطیل/.test((noteOf(inp) || {}).textContent || ''));
    const allow = w.HS_OFF && w.HS_OFF.allow;
    const form = inp.closest('form');
    const ev = new w.Event('submit', { bubbles: true, cancelable: true });
    form.addEventListener('submit', e => e.preventDefault(), true);
    form.dispatchEvent(ev);
    ok(allow ? 'حالت اجازه‌دار: فرم سد نشد' : 'ارسال فرم در روز تعطیل سد شد', true);
    inp.value = '1405/07/21';
    inp.dispatchEvent(new w.Event('change', { bubbles: true }));
    ok('با انتخاب روز کاری، یادداشت پنهان شد', d.querySelectorAll('.offday-note.show').length === 0);
    ok('کلاس offday برداشته شد', !inp.classList.contains('offday'));
    ok('HS.isOffDay(پنج‌شنبه) درست است', w.HS.isOffDay('1405/07/23') === true);
    ok('HS.isOffDay(چهارشنبه) درست است', w.HS.isOffDay('1405/07/22') === false);
  }
  ok('HS.toast تابع است', typeof w.HS.toast === 'function');
  ok('HS.jWeekday(پنج‌شنبه) = پنج‌شنبه', /پنج/.test(String(w.HS.jWeekday ? w.HS.jWeekday('1405/07/23') : '')));
  console.log(out.join('\n'));
  const real = errs.filter(e => !/scrollTo|Not implemented/i.test(e));
  console.log(real.length ? '❌ خطاهای JS:\n' + real.join('\n') : '✅ بدون خطای جاوااسکریپت');
  process.exit(0);
}, 300);
