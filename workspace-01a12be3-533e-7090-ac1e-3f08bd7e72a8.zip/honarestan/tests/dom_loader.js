
const fs=require('fs'); const {JSDOM, VirtualConsole}=require(process.env.JSDOM_PATH || 'jsdom');
const vc=new VirtualConsole(); const errs=[];
vc.on('jsdomError',e=>{ if(!/Not implemented/.test(e.message)) errs.push(e.message); });
const dom=new JSDOM(fs.readFileSync(process.argv[2] || 'rz.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true,url:'http://127.0.0.1:8080/records.php?tab=delay',virtualConsole:vc});
const w=dom.window, d=w.document, out=[], ok=(n,c)=>out.push((c?'✅':'❌')+' '+n);
setTimeout(()=>{
  const ld=()=>d.getElementById('loader');
  const shown=()=>{const l=ld(); return !!l && l.classList.contains('show');};
  const offForm=[...d.querySelectorAll('form')].find(f=>f.querySelector('[data-offcheck]') && f.getAttribute('data-loading'));
  ok('فرم دارای تاریخ پیدا شد', !!offForm);
  if (offForm) {
    const sid=d.getElementById('delayStudentId'); if (sid) sid.value='1';
    const inp=offForm.querySelector('[data-offcheck]');
    inp.value='1405/07/23';
    inp.dispatchEvent(new w.Event('change',{bubbles:true}));
    const ev=new w.Event('submit',{bubbles:true,cancelable:true});
    offForm.dispatchEvent(ev);
    ok('ارسال در روز تعطیل سد شد (defaultPrevented)', ev.defaultPrevented);
    setTimeout(()=>{
      ok('لودر برای ارسال سدشده نمایش داده نشد', !shown());
      inp.value='1405/07/19';
      inp.dispatchEvent(new w.Event('change',{bubbles:true}));
      offForm.dataset.confirmed='1';
      offForm.dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));
      setTimeout(()=>{
        ok('ارسال معتبر → لودر نمایش داده شد', shown());
        ok('متن لودر درست است', /در حال/.test(ld().textContent));
        setTimeout(()=>{
          const b=ld().querySelector('button[data-ld-close]');
          ok('پس از ۴ ثانیه دکمهٔ «بستن این پیام» اضافه شد', !!b);
          if (b) b.dispatchEvent(new w.Event('click',{bubbles:true}));
          ok('کلیک روی بستن، لودر را پنهان کرد', !shown());
          w.HS.loading(true,'تست'); ok('HS.loading(true) دوباره نمایش داد', shown());
          w.HS.hideLoader(); ok('HS.hideLoader پنهان کرد', !shown());
          w.HS.loading(true,'در حال پردازش…');
          const before=shown(); w.HS.toast('خطای سرور','err');
          ok('لودر باز + پیام خطا → لودر خودکار بسته شد', before && !shown());
          console.log(out.join('\n'));
          console.log(errs.length? '❌ خطای JS:\n'+errs.join('\n') : '✅ بدون خطای جاوااسکریپت');
          process.exit(0);
        },4300);
      },60);
    },60);
  }
},400);
