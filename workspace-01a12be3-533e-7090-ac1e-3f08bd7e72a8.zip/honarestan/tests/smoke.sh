#!/bin/bash
# اسموک تست نسخهٔ ۱.۳.۰ — مسیرها × نقش‌ها + بررسی جای‌گاه‌های پنل معلم
B=http://127.0.0.1:8080
declare -A U=( [admin]="admin:admin123" [deputy]="deputy:Deputy@1404" [teacher]="teacher:Teacher@1404" [supervisor]="supervisor:Supervisor@1404" )
declare -A J
for r in "${!U[@]}"; do
  IFS=: read -r u p <<< "${U[$r]}"
  jar=/tmp/sm3_$r.txt; rm -f $jar
  t=$(curl -s -c $jar "$B/index.php" | grep -o 'csrf_token" value="[^"]*"' | head -1 | sed 's/.*value="//;s/"$//')
  code=$(curl -s -b $jar -c $jar -X POST "$B/index.php" --data-urlencode "csrf_token=$t" --data-urlencode "action=login" \
     --data-urlencode "username=$u" --data-urlencode "password=$p" -o /dev/null -w "%{http_code}")
  J[$r]=$jar
  printf "  ورود %-11s → %s\n" "$r" "$code"
done

ROUTES=("/index.php" "/records.php" "/records.php?tab=bulk" "/records.php?tab=absence" "/records.php?tab=discipline"
 "/records.php?tab=dress" "/records.php?jdate=1405/07/21&tab=delay" "/students.php" "/students.php?tab=bulk" "/students.php?page=2"
 "/students.php?grade=دهم" "/admin.php" "/export.php" "/export.php?mode=creators&quick=week"
 "/export.php?mode=delay&quick=month&print=1" "/index.php?ajax=1&action=stats"
 "/teacher.php" "/teacher.php?grade=دهم" "/teacher.php?grade=دهم&field=کامپیوتر"
 "/teacher.php?grade=یازدهم&field=مکانیک" "/teacher.php?grade=دوازدهم" "/teacher.php?grade=دوازدهم&field=کامپیوتر")

fail=0
for r in admin deputy teacher supervisor; do
  bad=""
  for u in "${ROUTES[@]}"; do
    code=$(curl -s -b "${J[$r]}" -G "$B$u" -o /tmp/sm3_body.html -w "%{http_code}")
    err=$(grep -cE "Fatal error|Parse error|Warning:|Notice:|Deprecated:|SQLSTATE" /tmp/sm3_body.html)
    if [ "$err" != "0" ]; then bad="$bad\n     ❌ $u ($code) خطای PHP:$err"; fail=1; fi
  done
  echo "  — $r: ${#ROUTES[@]} مسیر $( [ -z "$bad" ] && echo '✅ سالم' || echo -e "$bad")"
done

echo "  ⛔ انتظار منع دسترسی:"
chk() { # نقش مسیر انتظار(403/200)
  code=$(curl -s -b "${J[$1]}" -G "$B$2" -o /tmp/sm3_forb.html -w "%{http_code}")
  if [ "$code" = "$3" ]; then echo "     ✅ $1 → $2 = $code"; else echo "     ❌ $1 → $2 = $code (انتظار: $3)"; fi
}
chk teacher /students.php 403
chk teacher /admin.php 403
chk deputy  /teacher.php 403
chk supervisor /teacher.php 403
chk admin /teacher.php 200
chk admin /students.php 200
echo "  نتیجه: $([ $fail = 0 ] && echo '✅ هیچ خطای PHP یافت نشد' || echo '❌ خطا')"
