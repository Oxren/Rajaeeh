
const fs=require('fs'); const {JSDOM, VirtualConsole}=require(process.env.JSDOM_PATH || 'jsdom');
const html=fs.readFileSync(process.argv[2],'utf8');
const errs=[]; const vc=new VirtualConsole();
vc.on('jsdomError',e=>errs.push('jsdomError: '+e.message)); vc.on('error',e=>errs.push('error: '+e));
const dom=new JSDOM(html,{runScripts:'dangerously',pretendToBeVisual:true,url:'http://127.0.0.1:8080/students.php',virtualConsole:vc});
setTimeout(()=>{
  const w=dom.window,d=w.document,out=[],ok=(n,c)=>out.push((c?'✅':'❌')+' '+n);
  const cbs=[...d.querySelectorAll('input[type="checkbox"][name="ids[]"]')];
  ok('چک‌باکس ردیف‌ها ساخته شد ('+cbs.length+')', cbs.length>0);
  ok('نوار عملیات گروهی وجود دارد', !!d.getElementById('selOpForm'));
  const run=d.getElementById('selRun'), cnt=d.getElementById('selCount'), all=d.getElementById('selAll');
  ok('دکمهٔ اجرا در ابتدا غیرفعال است', !!run && run.disabled);
  ok('شمارنده «۰ دانش‌آموز»', !!cnt && /۰/.test(cnt.textContent));
  ok('چک‌باکس «انتخاب همه» موجود است', !!all);
  if (all) {
    all.checked=true; all.dispatchEvent(new w.Event('change',{bubbles:true}));
    ok('با «انتخاب همه» همهٔ ردیف‌ها تیک خوردند', cbs.every(c=>c.checked));
    ok('شمارنده به‌روز شد', !/۰ دانش‌آموز/.test(cnt.textContent));
    ok('دکمهٔ اجرا فعال شد', !run.disabled);
    ok('ردیف‌های انتخاب‌شده هایلایت شدند (کلاس picked)', cbs[0].closest('tr').classList.contains('picked'));
  }
  const op=d.getElementById('selOp'), gsel=d.getElementById('selGrade'), fsel=d.getElementById('selField');
  if (op && gsel) {
    op.value='grade'; op.dispatchEvent(new w.Event('change',{bubbles:true}));
    ok('کادر «پایهٔ جدید» نمایش داده شد', !d.getElementById('selGradeBox').classList.contains('hidden'));
    gsel.value='دوازدهم'; gsel.dispatchEvent(new w.Event('change',{bubbles:true}));
    const opts=[...fsel.options].map(o=>o.value).filter(Boolean);
    ok('رشتهٔ کامپیوتر برای پایهٔ دوازدهم در فهرست نیست', opts.indexOf('کامپیوتر')===-1);
    ok('رشته‌های دوازدهم نمایش داده شد (۵ مورد)', opts.length===5);
    ok('همهٔ چک‌باکس‌ها به فرم عملیات گروهی متصل‌اند (form=)', cbs.every(c=>c.getAttribute('form')==='selOpForm'));
    op.value='field'; op.dispatchEvent(new w.Event('change',{bubbles:true}));
    ok('با انتخاب «تغییر رشته»، کادر رشته نمایش داده شد', !d.getElementById('selFieldBox').classList.contains('hidden'));
  }
  console.log(out.join('\n'));
  const real=errs.filter(e=>!/scrollTo|Not implemented/i.test(e));
  console.log(real.length?'❌ خطاهای JS:\n'+real.join('\n'):'✅ بدون خطای جاوااسکریپت');
  process.exit(0);
},350);
