#!/bin/bash
# ============================================================================
#  رگرسیون کامل سامانه — نسخهٔ ۱.۳.۱
#  اجرا:  JSDOM_PATH=/path/to/node_modules/jsdom bash tests/regress.sh
#  پیش‌نیاز: سرور آزمایشی بالا باشد  →  php -S 0.0.0.0:8080 router.php
# ============================================================================
set -o pipefail
cd "$(dirname "$0")/.." || exit 1
B=${HS_BASE:-http://127.0.0.1:8080}
J=${JSDOM_PATH:-jsdom}

echo "═══ ۱) اسموک‌تست مسیرها و دسترسی‌ها ═══"
bash tests/smoke.sh

echo; echo "═══ ۲) jsdom — پنل معلم ═══"
curl -s -b /tmp/sm3_teacher.txt -G "$B/teacher.php" --data-urlencode "grade=دهم" --data-urlencode "field=کامپیوتر" -o /tmp/tp_js.html
JSDOM_PATH=$J node tests/dom_teacher.js /tmp/tp_js.html

echo; echo "═══ ۳) jsdom — تعطیلی/تاریخ (۳ تب ثبت موارد) ═══"
i=0
for r in "records.php?tab=delay" "records.php?tab=absence" "records.php?tab=discipline"; do
  i=$((i+1)); f=/tmp/rg_$i.html
  curl -s -b /tmp/sm3_admin.txt -G "$B/$r" -o $f
  echo "  ── $r"
  JSDOM_PATH=$J node tests/dom_records.js $f "$r" | sed 's/^/    /'
done

echo; echo "═══ ۴) jsdom — لودر مقاوم ═══"
curl -s -b /tmp/sm3_admin.txt "$B/records.php?tab=delay" -o /tmp/rg_loader.html
JSDOM_PATH=$J node tests/dom_loader.js /tmp/rg_loader.html

echo; echo "═══ ۵) jsdom — انتخاب گروهی دانش‌آموزان ═══"
curl -s -b /tmp/sm3_admin.txt "$B/students.php" -o /tmp/rg_students.html
JSDOM_PATH=$J node tests/dom_students_bulk.js /tmp/rg_students.html

echo; echo "═══ ۶) jsdom — پنل ثبت گروهی ═══"
curl -s -b /tmp/sm3_admin.txt "$B/records.php?tab=bulk" -o /tmp/hs_r_bulk.html
JSDOM_PATH=$J node tests/dom_records_bulk.js
